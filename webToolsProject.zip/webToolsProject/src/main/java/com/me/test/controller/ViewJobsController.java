package com.me.test.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.test.dao.CreateEmployerDAO;
import com.me.test.dao.ViewJobsDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.Jobs;


@Controller

public class ViewJobsController {
	
	
	@Autowired
	@Qualifier("employerDao")
	CreateEmployerDAO employerDao;
	
	@Autowired
	@Qualifier("viewJobDao")
	ViewJobsDAO viewJobDao;
	
	@RequestMapping(value="/viewjobs.htm",method=RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String userName=(String)request.getSession().getAttribute("userName");
		  if(userName==null) 
			 {
			return new ModelAndView("redirect:signin.htm");
			 }
		
		ViewJobsDAO viewJobsDAO = null;
        List employerList = null;
        List<Jobs> jobList = new ArrayList<Jobs>();

        try {
            //CreateEmployerDAO employerDAO = new CreateEmployerDAO();
            employerList = employerDao.list();

            Iterator empIterator = employerList.iterator();

            while (empIterator.hasNext())
            {
                Employer employer = (Employer) empIterator.next();

                Iterator jobIterator = employer.getJobs().iterator();

                while (jobIterator.hasNext())
                {
                    Jobs jobs = (Jobs) jobIterator.next();
                    jobList.add(jobs);
                }
            }
            //DAO.close();
        } catch (AdException e) {
            System.out.println(e.getMessage());
        }

        ModelAndView mv = new ModelAndView("viewjobs", "jobList", jobList);
        return mv;
    }
	
	@RequestMapping(value="/viewJobDetails.htm",method=RequestMethod.POST)
	 protected ModelAndView viewJob(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String userName=(String)request.getSession().getAttribute("userName");
		  if(userName==null) 
		 {
		return new ModelAndView("redirect:signin.htm");
		 }
		
		Jobs job=null;
		try{
			//ViewJobsDAO viewJobDao= new ViewJobsDAO();
		
			int jobId=Integer.parseInt(request.getParameter("jobId"));
			System.out.println("Arey Job ID is: " + jobId);
			System.out.println("Arey Job ID is: " + jobId);
			job=viewJobDao.viewJobDetail(jobId);
			
		}
		catch (AdException e) {
            System.out.println(e.getMessage());
        }
		ModelAndView mv = new ModelAndView("viewJobDetails", "job", job);
        return mv;
		
	}
	
	
	@RequestMapping(value="/viewempjobs.htm",method=RequestMethod.GET)
    protected ModelAndView handleRequestEmpInternal(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String userName=(String)request.getSession().getAttribute("userName");
		  if(userName==null) 
			 {
			return new ModelAndView("redirect:signin.htm");
			 }
		
		List<Jobs> jobList = new ArrayList<Jobs>();
    try{
		//ViewJobsDAO viewJobDao= new ViewJobsDAO();
    	//String userName=(String)request.getSession().getAttribute("userName");
    	Employer employer=employerDao.viewProfile(userName);
    	   Iterator jobIterator = employer.getJobs().iterator();

           while (jobIterator.hasNext())
           {
               Jobs jobs = (Jobs) jobIterator.next();
               jobList.add(jobs);
           }
		
	}
	catch (AdException e) {
        System.out.println(e.getMessage());
    }
    ModelAndView mv = new ModelAndView("viewEmpJobs", "jobList", jobList);
    return mv;
    
	}
	
	@RequestMapping(value="/viewEmpJobDetails.htm",method=RequestMethod.POST)
	 public ModelAndView viewEmpJobDetails(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		Jobs job=null;
		try{
			//ViewJobsDAO viewJobDao= new ViewJobsDAO();
		
			int jobId=Integer.parseInt(request.getParameter("jobId"));
			System.out.println("Arey Job ID is: " + jobId);
			System.out.println("Arey Job ID is: " + jobId);
			job=viewJobDao.viewJobDetail(jobId);
			
		}
		catch (AdException e) {
           System.out.println(e.getMessage());
       }
		ModelAndView mv = new ModelAndView("viewEmpJobDetails", "job", job);
       return mv;
		
	}
	
	@RequestMapping(value="/deletejob.htm",method=RequestMethod.GET)
	 protected String deleteJob(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String userName=(String)request.getSession().getAttribute("userName");
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
		Jobs job=null;
		try{
			//ViewJobsDAO viewJobDao= new ViewJobsDAO();
		
			int jobId=Integer.parseInt(request.getParameter("jobId"));
			System.out.println("Arey Job ID is: " + jobId);
			System.out.println("Arey Job ID is: " + jobId);
			viewJobDao.deleteJob(jobId);
			
		}
		catch (AdException e) {
          System.out.println(e.getMessage());
      }
	
      return "redirect:viewempjobs.htm";
		
	}
	
	
}
