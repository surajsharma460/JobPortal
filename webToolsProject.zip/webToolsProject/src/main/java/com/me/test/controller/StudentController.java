package com.me.test.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.me.test.dao.CreateEmployerDAO;
import com.me.test.dao.CreateStudentDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.Student;
@Controller

public class StudentController {
	@Autowired
	@Qualifier("studentDAO")
	CreateStudentDAO studentDAO;
	
	
	
	@Autowired
	@Qualifier("studentProfileValidator")
	StudentProfileValidator studentProfileValidator;
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(studentProfileValidator);
	}
	
	@RequestMapping(value="/studentprofile.htm",method = RequestMethod.GET)
	public String initializeForm(@ModelAttribute("student")Student student, BindingResult result,HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Inside Student Controler");
		 String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
		 else
			 return "studentProfile";

}
	@RequestMapping(value="/studenthome.htm",method = RequestMethod.GET)
	public String student(@ModelAttribute("student")Student student, BindingResult result,HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Inside Student Controler");
 String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
	  
		return "studentHome";
	

}
	
	@RequestMapping(value="/studentprofile.htm",method = RequestMethod.POST)
	public String submitForm(@ModelAttribute("student") Student student, BindingResult result,HttpServletRequest request, HttpServletResponse response) throws AdException{
		studentProfileValidator.validate(student, result);
		String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
		
		
		if (result.hasErrors()) {
			return "studentProfile";
		}
		
		try{
		System.out.println("*********Inside submitForm1");
		System.out.println(student.getFirstName());
		//System.out.println(employer.getUserAccount().getUserId());
		//CreateStudentDAO studentDao= new CreateStudentDAO();
			System.out.println("*********Inside submitForm2");
			 //String userName=(String)request.getSession().getAttribute("userName");
	         System.out.println(userName);
	         studentDAO.create(userName,student.getNuid(),student.getFirstName(), student.getLastName(), student.getContact(),student.getStreet(),student.getCity(),student.getState(),student.getCountry());
			
			
		return "redirect:viewprofile.htm";	
		}
		catch (AdException e) {
			 System.out.println(e.getMessage());
			return "Error";
	           
	            
	        }
		}
	
	
}
