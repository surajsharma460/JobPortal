package com.me.test.controller;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.test.pojo.Employer;
import com.me.test.pojo.Jobs;

public class JobValidator  implements Validator  {

	 public boolean supports(Class aClass)
	    {
	        return aClass.equals(Jobs.class);
	    }

	    public void validate(Object obj, Errors errors)
	    {
	        Jobs user = (Jobs) obj;
	       // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nuid", "error.invalid.user", "NUID is Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "jobTitle", "error.invalid.user", "jobTitle  Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "jobDescription", "error.invalid.user", "jobDescription Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "jobLocation", "error.invalid.user", "jobLocation Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "salary", "error.invalid.user", "salary Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "jobduration", "error.invalid.user", "jobduration Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "term", "error.invalid.user", "term Required");
	      ;
	    }

}
