package com.me.test.controller;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.test.pojo.Student;

public class PortfolioValidator implements Validator  {

	 public boolean supports(Class aClass)
	    {
	        return aClass.equals(Student.class);
	    }

	    public void validate(Object obj, Errors errors)
	    {
	        Student user = (Student) obj;
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "degree", "error.invalid.user", "degree is Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "major", "error.invalid.user", "major is  Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gpa", "error.invalid.user", "gpa is Required");
	       // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contact", "error.invalid.user", "contact Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "preferedIndustry", "error.invalid.user", "Prefered Industry Required");
	  
	    } 

}
