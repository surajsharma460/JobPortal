package com.me.test.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.hibernate.annotations.SourceType;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.test.dao.CreateStudentDAO;
import com.me.test.dao.JobApplicationDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.Email;
import com.me.test.pojo.JobApplication;
import com.me.test.pojo.Student;
@Controller
public class ViewStudentProfile {
	@Autowired
	@Qualifier("studentDAO")
	CreateStudentDAO studentDAO;
	
	@Autowired
	@Qualifier("mail")
	Email mail;
	
	@Autowired
	@Qualifier("jobAppDAO")
	JobApplicationDAO jobAppDAO;
	
	@RequestMapping(value="/viewprofile.htm",method=RequestMethod.GET)
	public ModelAndView viewProfile(@ModelAttribute("student") Student student,HttpServletRequest request, HttpServletResponse response)throws Exception {
		
        String userName=(String)request.getSession().getAttribute("userName");
		
        if(userName==null) 
		 {
		return new ModelAndView("redirect:signin.htm");
		 }
        
        Student stud=null;

	      

	        try {
	        	//CreateStudentDAO studentDAO= new CreateStudentDAO();
	            stud= studentDAO.viewProfile(userName);
	            

	            
	            //DAO.close();
	        } catch (AdException e) {
	            System.out.println(e.getMessage());
	        }

	        ModelAndView mv = new ModelAndView("viewProfile", "student", stud);
	        return mv;
	    }
	
	@RequestMapping(value="/viewprofile.htm",method=RequestMethod.POST)
	public ModelAndView viewStudentProfile(@ModelAttribute("student") Student student,HttpServletRequest request, HttpServletResponse response)throws Exception {
		
       // 
		String userName2=(String)request.getSession().getAttribute("userName");
		  if(userName2==null) 
		 {
		return new ModelAndView("redirect:signin.htm");
		 }
        int applicationId=Integer.parseInt(request.getParameter("appId"));
        request.setAttribute("applicationId",applicationId);
		
        Student stud=null;

	      

	        try {
	        	//CreateStudentDAO studentDAO= new CreateStudentDAO();
	        	String userName=request.getParameter("userName");
	            stud= studentDAO.viewProfile(userName);
	            
	                    

	            
	            //DAO.close();
	        } catch (AdException e) {
	            System.out.println(e.getMessage());
	        }
	       
	        ModelAndView mv = new ModelAndView("viewStudentProfile", "student", stud);
	        
	        return mv;
	    }
	@RequestMapping(value="/decision.htm",method=RequestMethod.POST)
	public ModelAndView makeDecisions(HttpServletRequest request, HttpServletResponse response)throws Exception {
		String userName=(String)request.getSession().getAttribute("userName");
		  if(userName==null) 
		 {
		return new ModelAndView("redirect:signin.htm");
		 }
        System.out.println("******Decision Making**********");
        int applicationId=Integer.parseInt(request.getParameter("applicationId"));
        String empmessage=request.getParameter("empmessage");
        System.out.println(empmessage);
        String status=request.getParameter("status");
        System.out.println(status);
        
	
	      

	        try {
	        	//JobApplicationDAO jobApplicationDAO= new JobApplicationDAO();
	         
	        	if(status.equalsIgnoreCase("Interview Scheduled"))
	        	{
	        		mail.sendAcceptMail();
	        	}
	        	else{
	        		if(status.equalsIgnoreCase("Rejected"))
		        	{
		        		mail.rejectEmail();
		        	}
	        	}
	        	jobAppDAO.setDecision(applicationId,empmessage,status);
	            

	            
	            //DAO.close();
	        } catch (AdException e) {
	            System.out.println(e.getMessage());
	        }
	       
	        ModelAndView mv = new ModelAndView("redirect:/empapplication.htm");
	        
	        return mv;
	    }
	}
	

