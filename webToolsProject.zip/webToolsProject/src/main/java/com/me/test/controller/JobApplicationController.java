package com.me.test.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.test.dao.CreateJobDAO;
import com.me.test.dao.JobApplicationDAO;
import com.me.test.dao.ViewJobsDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.JobApplication;
import com.me.test.pojo.Jobs;

@Controller
public class JobApplicationController {
	@Autowired
	@Qualifier("viewJobDao")
	ViewJobsDAO viewJobDao;
	
	@RequestMapping(value="/application.htm",method = RequestMethod.POST)
public ModelAndView appForm(@ModelAttribute("application") JobApplication application,BindingResult result,HttpServletRequest request, HttpServletResponse response) throws AdException{
	
		String userName=(String)request.getSession().getAttribute("userName");
		  if(userName==null) 
		 {
		return new ModelAndView("redirect:signin.htm");
		 }
		int jobId=Integer.parseInt(request.getParameter("jobId"));
		//ViewJobsDAO viewJobDao= new ViewJobsDAO();
		
		//int jobId=Integer.parseInt(request.getParameter("jobId"));
		System.out.println("Arey Job ID is: " + jobId);
		System.out.println("Arey Job ID is: " + jobId);
		Jobs job=viewJobDao.viewJobDetail(jobId);
	ModelAndView mv = new ModelAndView("applicationForm", "job", job);
	
	return mv;
}

@RequestMapping(value="/submitApplication.htm",method = RequestMethod.POST)
public String appSubmit(@ModelAttribute("application") JobApplication application,BindingResult result,HttpServletRequest request, HttpServletResponse response) throws AdException{
	String userName=(String)request.getSession().getAttribute("userName");
	 
	 if(userName==null) 
	 {
	return "redirect:signin.htm";
	 }

	//System.out.println(employer.getUserAccount().getUserId());
	JobApplicationDAO jobappDao= new JobApplicationDAO();
		
		 //String userName=(String)request.getSession().getAttribute("userName");
         System.out.println(userName);
         
         int jobId=Integer.parseInt(request.getParameter("jobId"));
         JobApplication jobapplication=jobappDao.getApp(userName,jobId);
         
         if(jobapplication==null){
		jobappDao.create(userName,jobId,application.getMessage());
		return "studentSuccess";
         }
         else
         {
        	return "ErrorApplication"; 
         }
        	
	
	
	

	
}
}
