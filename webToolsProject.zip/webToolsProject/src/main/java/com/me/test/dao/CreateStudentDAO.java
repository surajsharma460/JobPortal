package com.me.test.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.Student;
import com.me.test.pojo.UserAccount;

public class CreateStudentDAO extends DAO{
	public CreateStudentDAO() {
   	 
    }



    public Student create(String userName,long nuid,String firstName, String lastName,long contact, String street, String city,String state,String country)
            throws AdException{
        try {
            begin();
            System.out.println("Inside Emp DAO");
            
          System.out.println(userName);
           Query query= getSession().createQuery("From UserAccount where userName=:userName");
           query.setString("userName", userName);
           UserAccount userAccount=(UserAccount)query.uniqueResult();
           Query q2=getSession().createQuery("From Student where userId=:userId");
           System.out.println("***********"+userAccount.getUserId());
           q2.setInteger("userId", userAccount.getUserId());
           Student student=(Student)q2.uniqueResult();
           	
           student.setNuid(nuid);
            student.setFirstName(firstName);
            student.setLastName(lastName);
            student.setContact(contact);
            student.setStreet(street);
            student.setCity(city);
            student.setState(state);
            student.setCountry(country);
            
            
 
            
            getSession().saveOrUpdate(student);
            
           
            
            commit();
            return student;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create user " + username, e);
            throw new AdException("Exception while creating student: " + e.getMessage());
        }
    }
    

    public Student uploadResume(String userName,String path,String name)
            throws AdException{
        try {
            begin();
           // System.out.println("Inside Emp DAO");
            
          //System.out.println(userName);
           Query query= getSession().createQuery("From UserAccount where userName=:userName");
           query.setString("userName", userName);
           UserAccount userAccount=(UserAccount)query.uniqueResult();
           Query q2=getSession().createQuery("From Student where userId=:userId");
           System.out.println("***********"+userAccount.getUserId());
           q2.setInteger("userId", userAccount.getUserId());
           Student student=(Student)q2.uniqueResult();
           student.setFileName(name);
           student.setFilePath(path);
        
        getSession().saveOrUpdate(student);
        
        
        
        commit();
        return student;
    } catch (HibernateException e) {
        rollback();
        //throw new AdException("Could not create user " + username, e);
        throw new AdException("Exception while creating student: " + e.getMessage());
    }
}
   public Student createPortfolio(String userName,String degree,String major,float gpa, String preferedIndustry,String employer, String jobTitle)
            throws AdException{
        try {
            begin();
            System.out.println("Inside portfolio DAO");
            
          System.out.println(userName);
           Query query= getSession().createQuery("From UserAccount where userName=:userName");
           query.setString("userName", userName);
           UserAccount userAccount=(UserAccount)query.uniqueResult();
           Query q2=getSession().createQuery("From Student where userId=:userId");
           System.out.println("***********"+userAccount.getUserId());
           q2.setInteger("userId", userAccount.getUserId());
           Student student=(Student)q2.uniqueResult();
           	
           student.setDegree(degree);
            student.setMajor(major);
            student.setGpa(gpa);
            student.setPreferedIndustry(preferedIndustry);
            student.setEmployer(employer);
            student.setJobTitle(jobTitle);
            
            
            
            
            
             
            
            getSession().saveOrUpdate(student);
            
           
            
            commit();
            return student;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create user " + username, e);
            throw new AdException("Exception while creating student: " + e.getMessage());
        }
    }
    
   public Student viewProfile(String userName)
           throws AdException{
       try {
           begin();
           System.out.println("Inside profile DAO");
           
         System.out.println(userName);
          Query query= getSession().createQuery("From UserAccount where userName=:userName");
          query.setString("userName", userName);
          UserAccount userAccount=(UserAccount)query.uniqueResult();
          Query q2=getSession().createQuery("From Student where userId=:userId");
          System.out.println("***********"+userAccount.getUserId());
          q2.setInteger("userId", userAccount.getUserId());
          Student student=(Student)q2.uniqueResult();
          	
           
           commit();
           return student;
       } catch (HibernateException e) {
           rollback();
           //throw new AdException("Could not create user " + username, e);
           throw new AdException("Exception while creating student: " + e.getMessage());
       }
   }
   
   public String getFile(Student student)throws AdException{
	   int id=student.getUserId();
	   System.out.println("**********************" + student.getFirstName());
	   
	   try{
		   begin();
		   
		   
		   commit();
	   }
	   
	   catch (HibernateException e) {
           rollback();
           //throw new AdException("Could not create user " + username, e);
           throw new AdException("Exception while creating student: " + e.getMessage());
       }
	   
	   return "path";
   }
   
}

    
