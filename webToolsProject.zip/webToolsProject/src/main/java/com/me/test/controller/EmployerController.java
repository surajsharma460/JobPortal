package com.me.test.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.test.dao.CreateEmployerDAO;
import com.me.test.dao.CreateUserDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.Student;
import com.me.test.pojo.UserAccount;

@Controller

public class EmployerController {
	@Autowired
	@Qualifier("employerDao")
	CreateEmployerDAO employerDao;
	
	
	@Autowired
	@Qualifier("empProfileValidator")
	EmpProfileValidator empProfileValidator;
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(empProfileValidator);
	}
	
	@RequestMapping(value="/empprofile.htm",method = RequestMethod.GET)
	public String initializeForm(@ModelAttribute("employer") Employer empoyer, BindingResult result,HttpServletRequest request, HttpServletResponse response) {
		String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }

		return "employerProfile";
	}
	
	@RequestMapping(value="/emphome.htm",method = RequestMethod.GET)
	public String empHome(@ModelAttribute("employer") Employer empoyer, BindingResult result,HttpServletRequest request, HttpServletResponse response) {
		String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
		
		return "employerHome";
	}
	
	@RequestMapping(value="/empprofile.htm",method=RequestMethod.POST)
	public String submitForm(@ModelAttribute("employer") Employer employer, BindingResult result,HttpServletRequest request, HttpServletResponse response) throws AdException{
		String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
		empProfileValidator.validate(employer, result);
		if (result.hasErrors()) {
			return "employerProfile";
		}
		
		try{
		
		System.out.println("*********Inside submitForm1");
	System.out.println(employer.getFirstName());
	//System.out.println(employer.getUserAccount().getUserId());
	//CreateEmployerDAO employerDao= new CreateEmployerDAO();
		System.out.println("*********Inside submitForm2");
		// String userName=(String)request.getSession().getAttribute("userName");
         System.out.println(userName);
		employerDao.create(userName,employer.getFirstName(), employer.getLastName(), employer.getContact(),employer.getStreet(),employer.getCity(),employer.getState(),employer.getCountry(),employer.getCompanyName());
		
	return "viewEmpProfile";
		}catch (AdException e) {
			 System.out.println(e.getMessage());
			return "Error";
	           
	            
	        }
	
	}
	
	@RequestMapping(value="/viewempprofile.htm",method=RequestMethod.GET)
	public ModelAndView viewProfile(@ModelAttribute("employer") Employer employer,HttpServletRequest request, HttpServletResponse response)throws Exception {
		
        String userName=(String)request.getSession().getAttribute("userName");
		
        if(userName==null) 
		 {
		return new ModelAndView("redirect:signin.htm");
		 }
       
        Employer emp=null;

	      

	        try {
	        	//CreateStudentDAO studentDAO= new CreateStudentDAO();
	            emp= employerDao.viewProfile(userName);
	            

	            
	            //DAO.close();
	        } catch (AdException e) {
	            System.out.println(e.getMessage());
	        }

	        ModelAndView mv = new ModelAndView("viewEmpProfile", "employer", emp);
	        return mv;
	    }
	
	

}
