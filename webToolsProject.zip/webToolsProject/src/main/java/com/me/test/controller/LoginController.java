package com.me.test.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.me.test.dao.CreateUserDAO;
import com.me.test.dao.LoginDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.UserAccount;

@Controller
@RequestMapping("/signin.htm")
public class LoginController extends HttpServlet {
	
	@Autowired
	@Qualifier("loginDao")
	LoginDAO loginDao;
	
	@Autowired
	@Qualifier("loginValidator")
	LoginValidator loginvalidator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(loginvalidator);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public String initializeForm(@ModelAttribute("userAccount") UserAccount userAccount, BindingResult result) {

		return "signin";
	}
	@RequestMapping(method=RequestMethod.POST)
	public String submitForm(@ModelAttribute("userAccount") UserAccount userAccount, BindingResult result,HttpServletRequest request,HttpServletResponse respnonse ) throws AdException{
		loginvalidator.validate(userAccount, result);
		if (result.hasErrors()) {
			return "signin";
		}
		
		System.out.println("*********Inside loginsubmitForm1");
		//LoginDAO loginDao= new LoginDAO();
		System.out.println("*********Inside loginsubmitForm2");
		
		try{
			
		UserAccount user=loginDao.login(userAccount.getUserName(), userAccount.getPassword());
		if(user==null){
			return "Error";
		}
		
		String userName=user.getUserName();
		
		
		
		
		if(user.getRole().equalsIgnoreCase("Employer"))
		{
			HttpSession session= request.getSession();
			session.setAttribute("userName", userName);
			return "employerHome";
		}
		else if(user.getRole().equalsIgnoreCase("Student"))
		{	
			HttpSession session= request.getSession();
			session.setAttribute("userName", userName);
			return "studentHome";
		}
		else
			return "Error";
		}
		catch (AdException e) {
			 System.out.println(e.getMessage());
			return "Error";
	           
	            
	        }
		
		
		
	
	}
	

}
