package com.me.test.dao;



import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.cfg.ExtendsQueueEntry;
import org.junit.runner.Request;

import com.me.test.exception.AdException;
import com.me.test.pojo.ParentUser;
import com.me.test.pojo.UserAccount;


public class LoginDAO extends DAO {
	private String loginUser;
	private String loginPassword;
	 public LoginDAO() {
    	 
	    }
	    public UserAccount login(String userName, String password)throws AdException{
	    	UserAccount userAccount=null; 
	    	try {
	    		  
	              begin();
	              System.out.println(userName);
	              System.out.println(password);
	              System.out.println("Before query");
	              try{
	              Query q = getSession().createQuery("from UserAccount where userName= :userName and password= :password");
	              q.setString("userName", userName);
	              q.setString("password", password);
	              System.out.println("After query");
	              userAccount = (UserAccount) q.uniqueResult();
	              }
	              catch(NullPointerException e){
	            	  System.out.println("User Not found");
	            	  return userAccount;
	              }
	             
	              commit();
	            //  System.out.println("Role of User is: "+ userAccount.getRole());
	              return userAccount;
	          } catch (HibernateException e) {
	              rollback();
	              throw new AdException("Could not get user " + userName, e);
	          }
	      }


}
