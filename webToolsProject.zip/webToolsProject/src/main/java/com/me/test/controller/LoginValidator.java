package com.me.test.controller;

//import com.yusuf.spring.pojo.User;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.me.test.pojo.UserAccount;

import org.springframework.validation.ValidationUtils;

public class LoginValidator implements Validator {

    public boolean supports(Class aClass)
    {
        return aClass.equals(UserAccount.class);
    }

    public void validate(Object obj, Errors errors)
    {
        UserAccount user = (UserAccount) obj;
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "error.invalid.user", "User Name is Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.invalid.user", "Password  Required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailId", "error.invalid.user", "Email Required");

    }
}
