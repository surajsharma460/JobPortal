package com.me.test.pojo;



import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

@Entity
public class JobApplication {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int jobApplicationId;
	
	
	

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name = "student_id")
	private Student student;
    

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name = "job_id")
	private Jobs job;
    
    private Date dateOfApplication;
    
    @Lob
    private String message;
    
    @Lob
    private String empmessage;
    
    private String action;
    private String status;

	public String getEmpmessage() {
		return empmessage;
	}

	public void setEmpmessage(String empmessage) {
		this.empmessage = empmessage;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getJobApplicationId() {
		return jobApplicationId;
	}

	public void setJobApplicationId(int jobApplicationId) {
		this.jobApplicationId = jobApplicationId;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Jobs getJob() {
		return job;
	}

	public void setJob(Jobs job) {
		this.job = job;
	}

	public Date getDateOfApplication() {
		return dateOfApplication;
	}

	public void setDateOfApplication(Date dateOfApplication) {
		this.dateOfApplication = dateOfApplication;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
    
    
   public JobApplication(){
	   
   } 
    
}
