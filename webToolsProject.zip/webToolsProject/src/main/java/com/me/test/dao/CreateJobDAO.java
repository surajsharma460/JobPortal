package com.me.test.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Controller;

import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.Jobs;
import com.me.test.pojo.ParentUser;
import com.me.test.pojo.UserAccount;


public class CreateJobDAO extends DAO {
	
public CreateJobDAO(){
	
}

public Jobs create(String userName,String title, String jobDesc, String jobCategory,
					String jobType, String jobLocation, String salary, String expeienceLevel,
					String totalExperience, String degree, String jobduration, String term)throws AdException{
	
	try {
        begin();
        System.out.println("Inside Emp DAO");
        
      System.out.println(userName);
       Query query= getSession().createQuery("From UserAccount where userName=:userName");
       query.setString("userName", userName);
       UserAccount userAccount=(UserAccount)query.uniqueResult();
       Query q2=getSession().createQuery("From Employer where userId=:userId");
       System.out.println("***********"+userAccount.getUserId());
       q2.setInteger("userId", userAccount.getUserId());
       Employer employer=(Employer)q2.uniqueResult();
       	
       Jobs jobs=new Jobs();
       jobs.setJobTitle(title);
       jobs.setJobDesc(jobDesc);
       jobs.setJobType(jobType);
       jobs.setJobLocation(jobLocation);
       jobs.setSalary(salary);
       jobs.setExperienceLevel(expeienceLevel);
       jobs.setTotalExperience(totalExperience);
       jobs.setDegree(degree);
       jobs.setJobduration(jobduration);
       jobs.setTerm(term);
       
       employer.getJobs().add(jobs);
       jobs.setEmployer(employer);
       
       
       
       
        
        
        
         
        
        getSession().saveOrUpdate(jobs);
        
       
        
        commit();
        return jobs;
    } catch (HibernateException e) {
        rollback();
        //throw new AdException("Could not create user " + username, e);
        throw new AdException("Exception while creating employer: " + e.getMessage());
    }
}

public void delete(ParentUser user)
        throws AdException {
    try {
        begin();
        getSession().delete(user);
        commit();
    } catch (HibernateException e) {
        rollback();
        throw new AdException("Could not delete user " + user.getFirstName(), e);
    }
}}