package com.me.test.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import org.hibernate.annotations.SourceType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.me.test.dao.CreateStudentDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.FileUpload;
import com.me.test.pojo.Student;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
 
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller

public class FileUploadController {
	@Autowired
    ServletContext context;
	
	@Autowired
	@Qualifier("studentDAO")
	CreateStudentDAO studentDAO;
	
	@Autowired
	@Qualifier("portfolioValidator")
	PortfolioValidator validator;
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}
	
	private static final int BUFFER_SIZE = 4096;
	
    private static final Logger logger = LoggerFactory
            .getLogger(FileUploadController.class);
 
    
    @RequestMapping(value="/portfolio.htm",method = RequestMethod.GET)
    public String initializeForm(@ModelAttribute("student")Student student,HttpServletRequest request, HttpServletResponse response){
    	System.out.println("file upload controller");
    	String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
    	
    	return "portfolio";
    }
    @RequestMapping(value="/portfolio.htm",method = RequestMethod.POST)
    public String uploadFileHandler(@ModelAttribute("student")Student student,@RequestParam("name") String name,
            @RequestParam("file") MultipartFile file,HttpServletRequest request, HttpServletResponse response) {
 
    	String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
    	
    	
    	if (!file.isEmpty()) {
            try {
                byte[] bytes = file.getBytes();
 
                // Creating the directory to store file
                String rootPath = System.getProperty("catalina.home");
                File dir = new File(rootPath + File.separator + "tmpFiles");
                if (!dir.exists())
                    dir.mkdirs();
 
                // Create the file on server
                File serverFile = new File(dir.getAbsolutePath()
                        + File.separator + name);
                BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(serverFile));
                stream.write(bytes);
                stream.close();
                String path=serverFile.getAbsolutePath();
                System.out.println(path);
 
                logger.info("Server File Location="
                        + path);
                //CreateStudentDAO studentDAO= new CreateStudentDAO();
               // String userName=(String)request.getSession().getAttribute("userName");
                studentDAO.uploadResume(userName,path,name);
                request.setAttribute("name", name);
                
                HttpSession session=request.getSession();
                session.setAttribute("path", path);
                session.setAttribute("name", name);
                
                return "portfolio";
            } catch (Exception e) {
                return "You failed to upload " + name + " => " + e.getMessage();
            }
        } else {
            return "You failed to upload " + name
                    + " because the file was empty.";
        }
    }
    
    @RequestMapping(value="/download.htm",method= RequestMethod.GET)
    	public void doDownload(@ModelAttribute("student")Student student,HttpServletRequest request,
                HttpServletResponse response) throws IOException {
    		HttpSession session=request.getSession();
            // get absolute path of the application
       
    		
    		
    		String filePath=(String) request.getParameter("name");
           
          	
          	System.out.println("File path is: "+filePath);	
        
     
            // construct the complete absolute path of the file
                
            File downloadFile = new File(filePath);
            FileInputStream inputStream = new FileInputStream(downloadFile);
             
            // get MIME type of the file
            String mimeType = context.getMimeType(filePath);
            if (mimeType == null) {
                // set to binary type if MIME mapping not found
                mimeType = "application/octet-stream";
            }
            System.out.println("MIME type: " + mimeType);
     
            // set content attributes for the response
            response.setContentType(mimeType);
            response.setContentLength((int) downloadFile.length());
     
            // set headers for the response
            String headerKey = "Content-Disposition";
          //  String headerValue = String.format("attachment; filename=\"%s\"",
               //     downloadFile.getName());
            //response.setHeader(headerKey, headerValue);
     
            // get output stream of the response
            OutputStream outStream = response.getOutputStream();
     
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead = -1;
     
            // write bytes read from the input stream into the output stream
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, bytesRead);
            }
     
            inputStream.close();
            outStream.close();
     
        }
    
    
    @RequestMapping(value="/studentPortfolio.htm",method= RequestMethod.POST)
    public String createPortfolio(@ModelAttribute("student")Student student,BindingResult result,HttpServletRequest request, HttpServletResponse response)throws AdException{
    	
    	String userName=(String)request.getSession().getAttribute("userName");
		 
		 if(userName==null) 
		 {
		return "redirect:signin.htm";
		 }
		 
    	validator.validate(student, result);
    	if (result.hasErrors()) {
    		return "portfolio";
    	}
    		//CreateUserDAO userDao= new CreateUserDAO();
    		try{
    	//CreateStudentDAO studentDAO= new CreateStudentDAO();
        //String userName=(String)request.getSession().getAttribute("userName");
        studentDAO.createPortfolio(userName,student.getDegree(),student.getMajor(), student.getGpa(), student.getPreferedIndustry(),student.getEmployer(),student.getJobTitle());
    	return "redirect:viewprofile.htm";
    		}
    		catch (AdException e) {
   			 System.out.println(e.getMessage());
   			return "Error";
   	           
   	            
   	        }
   		
    }
    }
    




