package com.me.test.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.http.HttpRequest;

import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.ParentUser;
import com.me.test.pojo.Student;
import com.me.test.pojo.UserAccount;

public class CreateEmployerDAO extends DAO {

    public CreateEmployerDAO() {
    	 
    }



    public Employer create(String userName,String firstName, String lastName,long contact, String street, String city,String state,String country,String companyName)
            throws AdException{
        try {
            begin();
            System.out.println("Inside Emp DAO");
            
          System.out.println(userName);
           Query query= getSession().createQuery("From UserAccount where userName=:userName");
           query.setString("userName", userName);
           UserAccount userAccount=(UserAccount)query.uniqueResult();
           Query q2=getSession().createQuery("From Employer where userId=:userId");
           System.out.println("***********"+userAccount.getUserId());
           q2.setInteger("userId", userAccount.getUserId());
           Employer employer=(Employer)q2.uniqueResult();
           	
            employer.setFirstName(firstName);
            employer.setLastName(lastName);
            employer.setContact(contact);
            employer.setStreet(street);
            employer.setCity(city);
            employer.setState(state);
            employer.setCountry(country);
            employer.setCompanyName(companyName);
            
            
            
             
            
            getSession().saveOrUpdate(employer);
            
           
            
            commit();
            return employer;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create user " + username, e);
            throw new AdException("Exception while creating employer: " + e.getMessage());
        }
    }

    public void delete(ParentUser user)
            throws AdException {
        try {
            begin();
            getSession().delete(user);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not delete user " + user.getFirstName(), e);
        }
    }
    
    public List list() throws AdException {
        try {
            begin();
            Query q = getSession().createQuery("from Employer");
            List list = q.list();
            commit();
            return list;
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not list the employers", e);
        }
    }
    
    public Employer viewProfile(String userName)
            throws AdException{
        try {
            begin();
            System.out.println("Inside profile DAO");
            
          System.out.println(userName);
           Query query= getSession().createQuery("From UserAccount where userName=:userName");
           query.setString("userName", userName);
           UserAccount userAccount=(UserAccount)query.uniqueResult();
           Query q2=getSession().createQuery("From Employer where userId=:userId");
           System.out.println("***********"+userAccount.getUserId());
           q2.setInteger("userId", userAccount.getUserId());
           Employer employer=(Employer)q2.uniqueResult();
           	
            
            commit();
            return employer;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create user " + username, e);
            throw new AdException("Exception while creating student: " + e.getMessage());
        }
    }
}
