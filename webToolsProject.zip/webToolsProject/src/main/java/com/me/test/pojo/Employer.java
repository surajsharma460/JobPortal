package com.me.test.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(name="userId")
public class Employer extends ParentUser {
	
	private String companyName;
	private String website;
	private String description;
	
	@OneToMany(fetch=FetchType.EAGER, mappedBy="employer")
	private Set<Jobs> jobs= new HashSet<Jobs>();
	public Set<Jobs> getJobs() {
		return jobs;
	}
	public void setJobs(Set<Jobs> jobs) {
		this.jobs = jobs;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Employer() {
		// TODO Auto-generated constructor stub
	}
	

}
