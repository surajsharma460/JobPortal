package com.me.test.dao;

import org.hibernate.HibernateException;

import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.ParentUser;
import com.me.test.pojo.Student;
import com.me.test.pojo.UserAccount;




public class CreateUserDAO extends DAO {

    public CreateUserDAO() {
    	 
    }



    public UserAccount create(String userName, String password,String emailId, String role)
            throws AdException{
        try {
            begin();
            System.out.println("**********SURAJ*************************inside DAO");
            
           
           UserAccount userAccount=new UserAccount();
          
           
           
            userAccount.setUserName(userName);
            userAccount.setPassword(password);
            userAccount.setEmailId(emailId);
            userAccount.setRole(role);
          
            
            getSession().save(userAccount);
            
            if(userAccount.getRole().equalsIgnoreCase("Employer")){
            	Employer employer=new Employer();
            	
            	userAccount.setUser(employer);
            	employer.setUserAccount(userAccount);
            	//employer.setUserId(userAccount.getUserId());
            	getSession().save(employer);
            	
            }
            else{
            	Student student=new Student();
            	student.setUserAccount(userAccount);
            	getSession().save(student);
            }
          // user.setFirstName("surajroxx");
           // user.setLastName("sharma");
            
            
             
            
         
          // 
           
            
            commit();
            return userAccount;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create user " + username, e);
            throw new AdException("Exception while creating user: " + e.getMessage());
        }
    }

    public void delete(ParentUser user)
            throws AdException {
        try {
            begin();
            getSession().delete(user);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not delete user " + user.getFirstName(), e);
        }
    }
}