package com.me.test.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="user_Account")
public class UserAccount {
	public UserAccount(){
		
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="userID", unique=true, nullable= false)
	private int userId;
	
	@Column(name="userName",unique=true, nullable= false)
	private String userName;
	
	@Column(name="password")
	private String password;
	
	@Column(name="emailId",unique=true, nullable= false)
	private String emailId;
	
	
	@Column(name="role")
	private String role;
	
	
	
	@OneToOne(fetch=FetchType.EAGER, mappedBy="userAccount", cascade=CascadeType.ALL)
    private ParentUser user;
	
	
	

	public ParentUser getUser() {
		return user;
	}

	public void setUser(ParentUser user) {
		this.user = user;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	
	
}
