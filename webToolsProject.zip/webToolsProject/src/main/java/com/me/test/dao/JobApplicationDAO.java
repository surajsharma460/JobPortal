package com.me.test.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.JobApplication;
import com.me.test.pojo.Jobs;
import com.me.test.pojo.Student;
import com.me.test.pojo.UserAccount;

public class JobApplicationDAO extends DAO {
	
	public JobApplication create(String userName,int jobId, String message)throws AdException{
		JobApplication application =new JobApplication();
		try {
	        begin();
	        System.out.println("Inside Emp DAO");
	        
	      System.out.println(userName);
	       Query query= getSession().createQuery("From UserAccount where userName=:userName");
	       query.setString("userName", userName);
	       UserAccount userAccount=(UserAccount)query.uniqueResult();
	       Query q2=getSession().createQuery("From Student where userId=:userId");
	       System.out.println("***********"+userAccount.getUserId());
	       q2.setInteger("userId", userAccount.getUserId());
	       Student student=(Student)q2.uniqueResult();
	       
	       Query q3=getSession().createQuery("From Jobs where jobId=:jobId");
	   
	       q3.setInteger("jobId",jobId);
	      Jobs job=(Jobs)q3.uniqueResult();
	       	
	     JobApplication jobapp=new JobApplication();
	      jobapp.setMessage(message);
	      jobapp.setDateOfApplication(new Date());
	      jobapp.setStatus("Pending");
	      student.getJobApplication().add(jobapp);
	      job.getJobApplication().add(jobapp);
	      
	      jobapp.setStudent(student);
	      jobapp.setJob(job);
	      
	
	        
	        getSession().saveOrUpdate(jobapp);
	        
	       
	        
	        commit();
	        return application;
	    } catch (HibernateException e) {
	        rollback();
	        //throw new AdException("Could not create user " + username, e);
	        throw new AdException("Exception while creating employer: " + e.getMessage());
	    }

		
	}
	
	public List<JobApplication> appList(String userName)throws AdException{
		 Query query= getSession().createQuery("From UserAccount where userName=:userName");
	       query.setString("userName", userName);
	       UserAccount userAccount=(UserAccount)query.uniqueResult();
	       Query q2=getSession().createQuery("From Student where userId=:userId");
	       System.out.println("***********"+userAccount.getUserId());
	       q2.setInteger("userId", userAccount.getUserId());
	       Student student=(Student)q2.uniqueResult();
		System.out.println("Studnet name is :"+ student.getFirstName());
        try {
            begin();
            Query q = getSession().createQuery("From JobApplication where student=:studentid");
            q.setInteger("studentid",student.getUserId());
            List<JobApplication> jobApplication=q.list();
            return jobApplication;
        }
        catch (HibernateException e) {
            rollback();
            throw new AdException("Could not get student " + userName, e);
        }

}
	public List<JobApplication> empappList(String userName)throws AdException{
		 Query query= getSession().createQuery("From UserAccount where userName=:userName");
	       query.setString("userName", userName);
	       UserAccount userAccount=(UserAccount)query.uniqueResult();
	       Query q2=getSession().createQuery("From Employer where userId=:userId");
	       System.out.println("***********"+userAccount.getUserId());
	       q2.setInteger("userId", userAccount.getUserId());
	       int x=userAccount.getUserId();
	      
	       Employer employer=(Employer)q2.uniqueResult();
		System.out.println("Studnet name is :"+ employer.getFirstName());
       try {
           begin();
         /*Query q = getSession().createQuery("From JobApplication where JobApplication.jobId=(select jobId from Jobs where Jobs.emp));
           q.setInteger("studentid",employer.getUserId());
           List<JobApplication> jobApplication=q.list();*/
           Query q= getSession().createSQLQuery("Select * from jobapplication where job_id IN (select jobId from jobs where employer_id="+ x +")").addEntity(JobApplication.class);
           List jobApplication=q.list();
           
           return jobApplication;
           
       }
       catch (HibernateException e) {
           rollback();
           throw new AdException("Could not get student " + userName, e);
       }

}
	
	public void setDecision(int applicationId, String empmessage,String status)throws AdException{
		 try {
	            begin();
	            System.out.println("Making Decision");
	            Query q = getSession().createQuery("From JobApplication where jobApplicationId=:applicationId");
	            q.setInteger("applicationId",applicationId);
	            JobApplication jobApplication=(JobApplication) q.uniqueResult();
	            jobApplication.setEmpmessage(empmessage);
	            jobApplication.setStatus(status);
	            System.out.println("Done");
	            
	            getSession().saveOrUpdate(jobApplication);
	            commit();
	        	
	        
	        }
	        catch (HibernateException e) {
	            rollback();
	            
	        }

		
	}
	public JobApplication getApp(String userName, int jobId){
		JobApplication jobApplication=null; 
		try {
	            begin();
	            Query query= getSession().createQuery("From UserAccount where userName=:userName");
	 	       query.setString("userName", userName);
	 	       UserAccount userAccount=(UserAccount)query.uniqueResult();
	 	       int x= userAccount.getUserId();
	 	       System.out.println("+++++++++++" + x);
	 	       System.out.println("+++++++++++" + jobId);
	 	       try{
Query q= getSession().createSQLQuery("Select * from jobapplication where job_id="+jobId+" and student_id="+x+" limit 1").addEntity(JobApplication.class);
	           System.out.println("kuch bhi");

	 	       jobApplication =(JobApplication)q.uniqueResult();
	           System.out.println("Student Message is: "+jobApplication.getMessage());
	 	       }
	 	      catch(NullPointerException e)
	 	        {
	 	            System.out.print("NullPointerException caught");
	 	            jobApplication=null;
	 	            return jobApplication;
	 	        }
	            commit();
//	 	    	  Criteria cr = getSession().createCriteria(JobApplication.class);
//
//	 	    	// To get records having salary more than 2000
//	 	    	cr.createCriteria("job").add(Restrictions.eq("jobId", jobId));
//	 	    	cr.createCriteria("student").add(Restrictions.eq("userId", x));
	 	    	//q.setMaxResults(1);  
	        
	        }
	        catch (HibernateException e) {
	            rollback();
	            
	        }
		 return jobApplication;
		
	}

}
