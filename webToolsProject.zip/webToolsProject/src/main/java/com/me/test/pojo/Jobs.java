package com.me.test.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;

@Entity
public class Jobs {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int jobId;
	private String jobTitle;
	@Lob
	private String jobDesc;
	private String jobCategory;
	private String jobType;
	private String jobLocation;
	private String salary;
	private String experienceLevel;
	private String totalExperience;
	private String degree;
	private String jobduration;
	private String term;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="employer_id", nullable=false)
	private Employer employer;
	
	 @OneToMany(mappedBy = "job",fetch=FetchType.EAGER)
	 @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE,org.hibernate.annotations.CascadeType.DELETE,org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
	 private Set<JobApplication> jobApplication = new HashSet<JobApplication>();
	
	
	public Set<JobApplication> getJobApplication() {
		return jobApplication;
	}


	public void setJobApplication(Set<JobApplication> jobApplication) {
		this.jobApplication = jobApplication;
	}


	public String getJobduration() {
		return jobduration;
	}


	public void setJobduration(String jobduration) {
		this.jobduration = jobduration;
	}


	public String getTerm() {
		return term;
	}


	public void setTerm(String term) {
		this.term = term;
	}


	
	
	
	public int getJobId() {
		return jobId;
	}


	public void setJobId(int jobId) {
		this.jobId = jobId;
	}


	public String getJobTitle() {
		return jobTitle;
	}


	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}


	public String getJobDesc() {
		return jobDesc;
	}


	public void setJobDesc(String jobDesc) {
		this.jobDesc = jobDesc;
	}


	public String getJobCategory() {
		return jobCategory;
	}


	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}


	public String getJobType() {
		return jobType;
	}


	public void setJobType(String jobType) {
		this.jobType = jobType;
	}


	public String getJobLocation() {
		return jobLocation;
	}


	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}


	public String getSalary() {
		return salary;
	}


	public void setSalary(String salary) {
		this.salary = salary;
	}


	public String getExperienceLevel() {
		return experienceLevel;
	}


	public void setExperienceLevel(String experienceLevel) {
		this.experienceLevel = experienceLevel;
	}


	public String getTotalExperience() {
		return totalExperience;
	}


	public void setTotalExperience(String totalExperience) {
		this.totalExperience = totalExperience;
	}


	public String getDegree() {
		return degree;
	}


	public void setDegree(String degree) {
		this.degree = degree;
	}


	public Employer getEmployer() {
		return employer;
	}


	public void setEmployer(Employer employer) {
		this.employer = employer;
	}


	public Jobs(){
		
	}

}
