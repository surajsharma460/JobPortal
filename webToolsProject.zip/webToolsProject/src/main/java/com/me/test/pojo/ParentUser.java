package com.me.test.pojo;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;



@Entity
@Table(name="user_table")
@PrimaryKeyJoinColumn(name="userId")
@Inheritance(strategy=InheritanceType.JOINED)

public class ParentUser {

	
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "userAccount"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name="userId",unique = true, nullable = false)
	private int userId;

	//@Column(name="firstName")
	private String firstName;
	
	/*public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}*/
	@Column(name="lastName")
	private String lastName;

	private String street;
	private String city;
	private String state;
	private String country;	

	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	private long contact;
	
	
	
	 
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	@OneToOne(cascade=CascadeType.ALL)
	 @JoinColumn(name="userId", unique= true, nullable=true, insertable=true, updatable=true)
    private UserAccount userAccount;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	public UserAccount getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(UserAccount userAccount) {
		this.userAccount = userAccount;
	}
	public ParentUser(){
		
		
	}


}

