package com.me.test.dao;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.me.test.exception.AdException;
import com.me.test.pojo.Jobs;

public class ViewJobsDAO extends DAO{
	public Jobs viewJobDetail(int jobId)throws AdException{
		System.out.println("DAO me job Id is :"+ jobId);
        try {
            begin();
            Query q = getSession().createQuery("From Jobs where jobId=:jobId");
            q.setInteger(""
            		+ "jobId", jobId);
            Jobs job=(Jobs)q.uniqueResult();
            return job;
        }
        catch (HibernateException e) {
            rollback();
            throw new AdException("Could not get job " + jobId, e);
        }

}
	
	public void deleteJob(int jobId)throws AdException{
		System.out.println("DAO me job Id is :"+ jobId);
        try {
            begin();
            /*Query q = getSession().createQuery("Delete From JobApplcation where jobId=:jobId");
            q.setInteger("jobId", jobId);
            q.executeUpdate();*/
           /* Serializable id = new Long(jobId);
            Object persistentInstance = getSession().load(Jobs.class, id);
            if (persistentInstance != null) {
                getSession().delete(persistentInstance);
            }*/
           System.out.println("deleted job application");
            Query q2=getSession().createQuery("Delete From Jobs where jobId=:jobId");
            q2.setInteger("jobId", jobId);
            q2.executeUpdate();
            q2.executeUpdate();
            commit();
            
        }
        catch (HibernateException e) {
            rollback();
            throw new AdException("Could not get job " + jobId, e);
        }

}
	
	
}