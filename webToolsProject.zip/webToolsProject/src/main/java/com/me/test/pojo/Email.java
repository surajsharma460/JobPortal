package com.me.test.pojo;

import java.net.PasswordAuthentication;
import java.util.Properties;

import javax.mail.Session;

import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

public class Email {

 
	    private MailSender mailSender;  
	   
	    public void setMailSender(MailSender mailSender) {  
	        this.mailSender = mailSender;  
	    }  
	   
	    public void sendAcceptMail() {  
	        //creating message  
	    	  Properties props= new Properties();
	    	//props.put("mail.smtp.host", "smtp.gmail.com");
	    	//props.put("mail.smtp,socketFactory.port","25");
	    	//props.put("mail.smtp.socketFactory.class","javax.ner.ssl.SSLSocketFactory");
	    	//props.put("mail.smtp.auth", "true");
	    	//props.put("mail.smtp.port", "25");
	    	   props.put("mail.smtp.starttls.enable", "true");
	    	        props.put("mail.smtp.auth", "true");
	    	        props.put("mail.smtp.host", "smtp.gmail.com");
	    	        props.put("mail.smtp.port", "587");

	    	Session session = Session.getDefaultInstance(props,
	    			new javax.mail.Authenticator(){
	    		protected javax.mail.PasswordAuthentication getPasswordAuthentication(){
	    		return new javax.mail.PasswordAuthentication("suraj.sharma360@gmail.com","Ftsi@2010");

	    		}

	    		}

	    		);
	        SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("myneucool@gmail.com");  
	        message.setTo("myneucool@gmail.com");  
	        message.setSubject("Invitation for Interview");  
	        message.setText("Congratulations!! You are invited for interview");  
	        //sending message  
	        mailSender.send(message);     
	    } 
	    public void rejectEmail() { 
	    	  Properties props= new Properties();
		    	//props.put("mail.smtp.host", "smtp.gmail.com");
		    	//props.put("mail.smtp,socketFactory.port","25");
		    	//props.put("mail.smtp.socketFactory.class","javax.ner.ssl.SSLSocketFactory");
		    	//props.put("mail.smtp.auth", "true");
		    	//props.put("mail.smtp.port", "25");
		    	   props.put("mail.smtp.starttls.enable", "true");
		    	        props.put("mail.smtp.auth", "true");
		    	        props.put("mail.smtp.host", "smtp.gmail.com");
		    	        props.put("mail.smtp.port", "587");

		    	Session session = Session.getDefaultInstance(props,
		    			new javax.mail.Authenticator(){
		    		protected javax.mail.PasswordAuthentication getPasswordAuthentication(){
		    		return new javax.mail.PasswordAuthentication("suraj.sharma360@gmail.com","Ftsi@2010");

		    		}

		    		}

		    		);
	        //creating message  
	        SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("myneucool@gmail.com");  
	        message.setTo("myneucool@gmail.com");  
	        message.setSubject("Rejection Email");  
	        message.setText("Sorry!! at this moment we are moving forward with other candidates");  
	        //sending message  
	        mailSender.send(message);     
	    }
	  
}
