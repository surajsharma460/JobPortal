package com.me.test.controller;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.test.pojo.Student;
import com.me.test.pojo.UserAccount;

public class StudentProfileValidator implements Validator  {

	 public boolean supports(Class aClass)
	    {
	        return aClass.equals(Student.class);
	    }

	    public void validate(Object obj, Errors errors)
	    {
	        Student user = (Student) obj;
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nuid", "error.invalid.user", "NUID is Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "error.invalid.user", "firstName  Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "error.invalid.user", "lastName Required");
	       // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contact", "error.invalid.user", "contact Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "street", "error.invalid.user", "street Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "city", "error.invalid.user", "city Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "state", "error.invalid.user", "state Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "country", "error.invalid.user", "country Required");
	    }
}
