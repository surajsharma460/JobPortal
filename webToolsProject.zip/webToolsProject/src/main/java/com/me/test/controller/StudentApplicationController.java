package com.me.test.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.test.dao.CreateEmployerDAO;
import com.me.test.dao.JobApplicationDAO;
import com.me.test.dao.ViewJobsDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.Employer;
import com.me.test.pojo.JobApplication;
import com.me.test.pojo.Jobs;
import com.me.test.pojo.Student;

@Controller
public class StudentApplicationController {
	@Autowired
	@Qualifier("jobAppDAO")
	JobApplicationDAO jobAppDAO;
	@RequestMapping(value="/viewapplication.htm",method = RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String userName=(String)request.getSession().getAttribute("userName");
		if(userName==null) 
		 {
		return new ModelAndView("redirect:signin.htm");
		 }
		
		JobApplication jobApp = null;
        
        List<JobApplication> appList = new ArrayList<JobApplication>();
        //String userName=(String)request.getSession().getAttribute("userName");
      

        try {
            //JobApplicationDAO jobAppDAO = new JobApplicationDAO();
            appList = jobAppDAO.appList(userName);
            System.out.println(appList);

            
            //DAO.close();
        } catch (AdException e) {
            System.out.println(e.getMessage());
        }

        ModelAndView mv = new ModelAndView("studentApplication", "appList", appList);
        return mv;
    }

}
