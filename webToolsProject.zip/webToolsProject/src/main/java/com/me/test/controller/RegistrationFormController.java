package com.me.test.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.me.test.dao.CreateUserDAO;
import com.me.test.exception.AdException;
import com.me.test.pojo.ParentUser;
import com.me.test.pojo.UserAccount;




@Controller
@RequestMapping("/registration.htm")
public class RegistrationFormController {

	@Autowired
	@Qualifier("userValidator")
	UserValidator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}
	
	@Autowired
	@Qualifier("userDao")
	CreateUserDAO userDao;
	@RequestMapping(method = RequestMethod.GET)
	public String initializeForm(@ModelAttribute("userAccount") UserAccount userAccount, BindingResult result) {

		
		return "registration";
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public String submitForm(@ModelAttribute("userAccount") UserAccount userAccount, BindingResult result) throws AdException{
	System.out.println("*********Inside submitForm1");
	
	validator.validate(userAccount, result);
	if (result.hasErrors()) {
		return "registration";
	}
		//CreateUserDAO userDao= new CreateUserDAO();
		try{
		userDao.create(userAccount.getUserName(), userAccount.getPassword(), userAccount.getEmailId(),userAccount.getRole());
		return "success";
		} 
		catch (AdException e) {
			 System.out.println(e.getMessage());
			return "Error";
	           
	            
	        }
		
	
	}
}
