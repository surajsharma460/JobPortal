package com.me.test.dao;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil {

     private static SessionFactory sessionFactory;

     static {
        try {
        	System.out.println("n hib util");
            sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
            System.out.println("s created");
         }
         catch(Throwable t) {
             throw new ExceptionInInitializerError(t);
         }
     }

     public static SessionFactory getSessionFactory() {
         return sessionFactory;
     }

     public static void shutdown() {
         getSessionFactory().close();
     }
  }
